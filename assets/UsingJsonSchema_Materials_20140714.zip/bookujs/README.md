# Using JSON Schema: Programs and Examples

Part of the [Using JSON Schema](http://usingjsonschema.github.io) project.

This package contains the materials for the book
[Using JSON Schema](http://usingjsonschema.com) including,

- source code for the examples contained in the book
- source code for the program listings contained in the book

The full repositories for each of the programs are hosted on GitHub,
including test cases, that are beyond the scope of the book materials. Easy
navigation to the repositories is provided through the project page.

## License

MIT