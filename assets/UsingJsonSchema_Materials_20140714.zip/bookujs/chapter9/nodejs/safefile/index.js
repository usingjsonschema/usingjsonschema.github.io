module.exports.SafeFileError = require ("./SafeFileError").SafeFileError;
module.exports.safeFile = require ("./safeFile");
